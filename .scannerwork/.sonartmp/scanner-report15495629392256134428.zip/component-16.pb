 2javaX
hrXbackend/src/main/java/com/restaurant/rewards/application/out/RewardNotificationPort.java