( 2javaX
hrmbackend/src/main/java/com/restaurant/rewards/infrastructure/persistence/repository/JpaCustomerRepository.java